---BOARD SPECIFICATIONS---
File: tri-slot-feedlines_revC_CAM
Date: 19-Oct. 2020
Designer: Eric Oberla <ejo@uchicago.edu> / Dan Southall <dsouthall@uchicago.edu>
--------------------------

Board outer dimensions : 91.90 mm x 14 mm

2-layer board:
top layer: tri-slot-feedlines-F.Cu  (signal ) 
bottom layer: tri-slot-feedlines-B.Cu (signal  )

stackup height: 0.062" 

min. hole size: 0.4 mm

silkscreen: None
soldermask: None