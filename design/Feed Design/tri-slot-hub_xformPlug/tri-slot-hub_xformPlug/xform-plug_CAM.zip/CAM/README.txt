---BOARD SPECIFICATIONS---
File: xform-plug_CAM
Date: 6-Aug 2020
Designer: Eric Oberla <ejo@uchicago.edu>
--------------------------

2-layer board:
top layer: xform-plug-F.Cu  
bottom layer: xform-plug-B.Cu 

stackup height: 0.062" 

silkscreen: both sides
soldermask: both sides, green