---BOARD SPECIFICATIONS---
File: tri-slot-hub_CAM
Date: 12-Dec. 2019
Designer: Eric Oberla <ejo@uchicago.edu>
--------------------------

Board outer dimensions : 48.2 mm x 44.0 mm

2-layer board:
top layer: tri-slot-hub-F.Cu  (signal ) 
bottom layer: tri-slot-hub-B.Cu (signal  )

stackup height: 0.062" 

silkscreen: None
soldermask: None