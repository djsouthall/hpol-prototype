---BOARD SPECIFICATIONS---
File: quad-slot-hub_revA_CAM
Date: 20-Dec. 2020
Designer: Dan Southall <dsouthall@uchicago.edu>
--------------------------

Board outer dimensions : XX mm x YY mm

2-layer board:
top layer: quad-slot-hub-F.Cu  (signal ) 
bottom layer: quad-slot-hub-B.Cu (signal  )

stackup height: 0.062" 

silkscreen: None
soldermask: None